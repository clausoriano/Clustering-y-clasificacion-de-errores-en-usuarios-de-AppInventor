from django.shortcuts import render
import pymysql as pymysql
from django.views.decorators.clickjacking import xframe_options_exempt
from django.contrib.auth.decorators import login_required
import pandas as pd
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

query = "SELECT ID,question_id,answer_id,owner,score,category,text,date,time,sentiments,site FROM answers"
cursor.execute(query)
data = cursor.fetchall()
number_of_answers = len(data)

query = "SELECT ID,link,title,owner,username,text,score,views,date,time,about,tags,sentiments,site FROM questions"
cursor.execute(query)
data = cursor.fetchall()
number_of_questions = len(data)
df = pd.DataFrame(data, columns=['ID','link','title','owner','username','text','score','views','date','time','about','tags','sentiments','site'])
number_of_views = df['views'].sum()
number_of_likes = df['score'].sum()

query = "SELECT * FROM sentiments"
cursor.execute(query)
data = cursor.fetchall()
anger = data[0][0]
disgust = data[0][1]
fear = data[0][2]
joy = data[0][3]
neutral = data[0][4]
sadness = data[0][5]
surprise = data[0][6]



context = {
    "numberAnswers" : number_of_answers,
    "numberQuestions" : number_of_questions,
    "numberViews" : number_of_views,
    "numberLikes" : number_of_likes,
    "anger" : anger,
    "disgust" : disgust,
    "fear" : fear,
    "joy" : joy,
    "neutral" : neutral,
    "sadness" : sadness,
    "surprise" : surprise,
}

def home(requests):
    return render(requests, 'home/welcome.html', context)