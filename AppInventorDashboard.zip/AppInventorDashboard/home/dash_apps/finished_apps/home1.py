import pymysql as pymysql
from dash import dcc
from dash import html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

query = "SELECT ID,link,title,owner,username,text,score,views,date,time,about,tags,sentiments,site FROM questions"
cursor.execute(query)
data = cursor.fetchall()
df = pd.DataFrame(data, columns=['ID','link','title','owner','username','text','score','views','date','time','about','tags','sentiments','site'])
cat_labels = {'5':'MIT AppInventor Help','20':'Bugs and Other Issues','11':'General Discussion','17':'Extensions','10':'Open Source Development','19':'App Inventor for iOS',
          '12':'Tutorials and Guides','18':'App Showcase','14':'Data Storage','24':'Frequently Asked Questions','3':'Site Feedback','21':'Work for Hire','13':'User Interface and Graphics',
          '27':'Appathon','7':'Community','9':'News/Announcements','16':'Artificial Intelligence','29':'MIT App Inventor Alexa','28':'Translating App Inventor'}
site_labels={0:'Stack Overflow',1:'App Inventor Community Forum'}
df['about'] = df['about'].map(cat_labels)
df['site'] = df['site'].map(site_labels)

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

from django_plotly_dash import DjangoDash
app = DjangoDash('home1', external_stylesheets=external_stylesheets)


app.layout = html.Div([
    html.Div([
        html.H6(['Categories distribution']),
        dcc.Dropdown(
            id='my_dropdown',
            options=[
                {'label': 'Category', 'value': 'about'},
                {'label': 'Web site', 'value': 'site'}
            ],
            value='about',
            multi=False,
            clearable=False,
            style={"width":"50%","display":"none"}
        ),
    ]),

    html.Div([
        dcc.Graph(id='the_graph')
    ]),
])

@app.callback(Output('the_graph', 'figure'),[Input('my_dropdown', 'value')])
def display_value(my_dropdown):
    dff = df

    piechart=px.pie(
        data_frame=dff,
        names=my_dropdown,
        hole=.3,
        labels={'5':'MIT AppInventor Help'}
    )
    piechart.update_layout(margin=dict(t=0,b=0,l=0,r=0))
    return(piechart)