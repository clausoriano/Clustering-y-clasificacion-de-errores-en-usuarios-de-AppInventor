import pymysql as pymysql
from dash import dcc
from dash import html, Dash, dash_table
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from dash import dash_table
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

query = "SELECT anger,disgust,fear,joy,neutral,sadness,surprise FROM sentiments"
cursor.execute(query)
sentiments = cursor.fetchall()

data = [['Anger',sentiments[0][0]],['Disgust',sentiments[0][1]],['Fear',sentiments[0][2]],['Joy',sentiments[0][3]],['Neutral',sentiments[0][4]],['Sadness',sentiments[0][5]],['Surprise',sentiments[0][6]]]
sentiments_df = pd.DataFrame(data,columns=['name','value'])
sentiments_df['value'] = sentiments_df['value'].astype(float)

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
from django_plotly_dash import DjangoDash
app = DjangoDash('home3', external_stylesheets=external_stylesheets)

fig = px.bar(sentiments_df, x='name', y='value')
title = 'Overall sentiments'
fig.update_layout(title_text=title)
fig.update_layout(barmode='group',yaxis={"categoryorder":"total descending"})


app.layout = html.Div([
        html.Div(dcc.Graph(figure=fig)),
])