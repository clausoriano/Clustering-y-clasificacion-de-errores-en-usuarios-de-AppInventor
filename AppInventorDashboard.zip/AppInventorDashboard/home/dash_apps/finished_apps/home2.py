import pymysql as pymysql
from dash import dcc
from dash import html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

query = "SELECT ID,link,title,owner,username,text,score,views,date,time,about,tags,sentiments,site FROM questions"
cursor.execute(query)
data = cursor.fetchall()
df = pd.DataFrame(data, columns=['ID','link','title','owner','username','text','score','views','date','time','about','tags','sentiments','site'])
site_labels={0:'Stack Overflow',1:'App Inventor Community Forum'}
df['site'] = df['site'].map(site_labels)

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

from django_plotly_dash import DjangoDash
app = DjangoDash('home2', external_stylesheets=external_stylesheets)


app.layout = html.Div([
    html.Div([
        html.H6(['Site usage']),
        dcc.Dropdown(
            id='my_dropdown',
            options=[
                {'label': 'Web site', 'value': 'site'}
            ],
            value='site',
            multi=False,
            clearable=False,
            style={"width":"50%","display":"none"}
        ),
    ]),

    html.Div([
        dcc.Graph(id='the_graph')
    ]),
])

@app.callback(Output('the_graph', 'figure'),[Input('my_dropdown', 'value')])
def display_value(my_dropdown):
    dff = df

    piechart=px.pie(
        data_frame=dff,
        names=my_dropdown,
        hole=.3,
    )
    piechart.update_layout(margin=dict(t=0,b=0,l=0,r=0))
    piechart.update_layout(legend=dict(
        orientation="v",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1
    ))

    return(piechart)