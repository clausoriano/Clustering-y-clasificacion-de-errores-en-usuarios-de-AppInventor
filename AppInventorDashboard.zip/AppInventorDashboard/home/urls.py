from django.urls import path
from . import views
from home.dash_apps.finished_apps import home1
from home.dash_apps.finished_apps import home2
from home.dash_apps.finished_apps import home3
urlpatterns = [
    path('', views.home, name='home')

]