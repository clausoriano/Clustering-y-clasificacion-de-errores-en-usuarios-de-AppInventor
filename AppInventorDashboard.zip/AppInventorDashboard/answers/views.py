from django.shortcuts import render

# Create your views here.
def answers(requests):
    return render(requests, 'answers/answers.html')