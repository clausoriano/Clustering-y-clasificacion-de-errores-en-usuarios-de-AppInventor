import pymysql as pymysql
from dash import dcc
from dash import html, Dash, dash_table
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from dash import dash_table
import dash_bootstrap_components as dbc
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

# Questions dataframe
query = "SELECT link,title,owner,username,text,score,views,date,time,about,tags,site,sentiments FROM questions WHERE text != ''"
cursor.execute(query)
data = cursor.fetchall()
df = pd.DataFrame(data, columns=['link','title','owner','username','text','score','views','date','time','about','tags','site','sentiments'])
site_labels={0:'Stack Overflow',1:'App Inventor Community Forum'}
cat_labels = {'5':'MIT App Inventor Help','20':'Bugs and Other Issues','11':'General Discussion','17':'Extensions','10':'Open Source Development','19':'App Inventor for iOS',
          '12':'Tutorials and Guides','18':'App Showcase','14':'Data Storage','24':'Frequently Asked Questions','3':'Site Feedback','21':'Work for Hire','13':'User Interface and Graphics',
          '27':'Appathon','7':'Community','9':'News/Announcements','16':'Artificial Intelligence','29':'MIT App Inventor Alexa','28':'Translating App Inventor'}
df['site'] = df['site'].map(site_labels)
df['about'] = df['about'].map(cat_labels)
questions_df =df

# Answers dataframe
query = "SELECT question_id,answer_id,owner,score,category,text,date,time,sentiments FROM answers"
cursor.execute(query)
data = cursor.fetchall()
af = pd.DataFrame(data, columns=['question_id','answer_id','owner','score','category','text','date','time','sentiments'])
answers_df = af

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

from django_plotly_dash import DjangoDash
app = DjangoDash('table_answers', external_stylesheets=external_stylesheets)

# App layout
app.layout = html.Div([
    dash_table.DataTable(
        id='datatable-answers',
        columns=[
            {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
            for i in answers_df.columns
        ],
        hidden_columns=['sentiments'],
        data=answers_df.to_dict('records'),
        style_cell={    # ensure adequate header width when text is shorter than cell's text
            'overflow': 'hidden',
            'textOverflow': 'ellipsis',
            'maxWidth':50,
            'minWidth': 30,
            'width': 50
        },
        editable=False,
        filter_action="native",
        sort_action="native",
        sort_mode="single",
        column_selectable="none",
        row_selectable="single",
        row_deletable=False,
        selected_rows=[],
        page_action="native",
        page_current=0,
        page_size=10,
        tooltip_delay=0,
        tooltip_duration=None,
        tooltip_data=
        [
             {
                 column: {'value': str(value), 'type': 'markdown'}
                 for column, value in row.items()
             } for row in answers_df.to_dict('records')
        ],
        css=[
            {
                'selector': '.dash-table-tooltip',
                'rule': 'background-color: grey; color: white;'
            }
        ],
        style_cell_conditional=[  # align text columns to left. By default they are aligned to right
            {
                'if': {'column_id': c},
                'textAlign': 'left'
            } for c in ['text', 'title']
        ],

    ),

    html.Div([
            html.Div(dcc.Graph(id='fig'),style={'width': '50%', 'height': '100%', 'display': 'inline-block', 'float': 'right'}),
            html.H6("Question:",style={'width': '50%','height':'20%','display': 'inline-block','float':'right','vertical-align':'bottom'}),
            html.Div(id='titl',style={'width': '50%','height':'20%','display': 'inline-block','float':'right','vertical-align':'bottom','overflow-y':'scroll'}),
            html.Div(id='text',style={'width': '50%','height':'200px','display': 'inline-block','float':'right','vertical-align':'bottom','overflow-y':'scroll'}),
    ]),

])


@app.callback([
    Output('titl', 'children'),
    Output('text', 'children'),
    Output('fig', 'figure'),
], [Input('datatable-answers', 'selected_rows')])
def update_answers(selected_rows):

    if len(selected_rows) == 0:
        questions = af
    else:
        answer_id = answers_df.iloc[selected_rows]['answer_id']
        answer_id = answer_id.iloc[0]

        question_id = answers_df.iloc[selected_rows]['question_id']
        question_id = question_id.iloc[0]

        answer_sentiments = answers_df.iloc[selected_rows]['sentiments']
        answer_sentiments = answer_sentiments.iloc[0]

        question = questions_df.loc[questions_df['link'] == str(question_id)]
        question = question.reset_index(drop=True)
        question_text = question['text'][0]
        question_title = question['title'][0]
        question_sentiments = question['sentiments'][0]

        d1 = get_sentiments('Question',question_sentiments)
        d2 = get_sentiments('Answer',answer_sentiments)

        d = [d1,d2]
        sentiments = ['anger', 'disgust', 'fear', 'joy', 'neutral', 'sadness', 'surprise']
        sentiments_dataframe = pd.DataFrame(d, columns=['name', 'anger', 'disgust', 'fear', 'joy', 'neutral', 'sadness', 'surprise'])


        txt = html.P(question_text)
        title = html.H6(question_title)

        fig = go.Figure(data=[
            go.Bar(name='Question', x=sentiments,
                   y=[float(sentiments_dataframe.iloc[0]['anger']), float(sentiments_dataframe.iloc[0]['disgust']), float(sentiments_dataframe.iloc[0]['fear']),
                      float(sentiments_dataframe.iloc[0]['joy']), float(sentiments_dataframe.iloc[0]['neutral']), float(sentiments_dataframe.iloc[0]['sadness']),
                      float(sentiments_dataframe.iloc[0]['surprise'])]),
            go.Bar(name='Answer', x=sentiments,
                   y=[float(sentiments_dataframe.iloc[1]['anger']), float(sentiments_dataframe.iloc[1]['disgust']), float(sentiments_dataframe.iloc[1]['fear']),
                      float(sentiments_dataframe.iloc[1]['joy']), float(sentiments_dataframe.iloc[1]['neutral']), float(sentiments_dataframe.iloc[1]['sadness']),
                      float(sentiments_dataframe.iloc[1]['surprise'])]),

        ])
        fig.update_layout(title='Question vs. Answer sentiments')
    return title,txt,fig



def get_sentiments(what,sentiment):
    anger = 0
    disgust = 0
    fear = 0
    joy = 0
    neutral = 0
    sadness = 0
    surprise = 0

    sentiments = sentiment.split(",")
    anger = anger + float(sentiments[0].split(":")[1])
    disgust = disgust + float(sentiments[1].split(":")[1])
    fear = fear + float(sentiments[2].split(":")[1])
    joy = joy + float(sentiments[3].split(":")[1])
    neutral = neutral + float(sentiments[4].split(":")[1])
    sadness = sadness + float(sentiments[5].split(":")[1])
    surprise = surprise + float(sentiments[6].split(":")[1])

    anger = round(anger * 100, 1)
    disgust = round(disgust * 100, 1)
    fear = round(fear * 100, 1)
    joy = round(joy * 100, 1)
    neutral = round(neutral * 100, 1)
    sadness = round(sadness * 100, 1)
    surprise = round(surprise * 100, 1)

    d = [what,anger,disgust,fear,joy,neutral,sadness,surprise]

    return d