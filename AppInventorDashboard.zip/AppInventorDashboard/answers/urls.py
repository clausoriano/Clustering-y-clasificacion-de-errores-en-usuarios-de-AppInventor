from django.urls import path
from . import views
from answers.dash_apps.finished_apps import table_answers


urlpatterns = [
    path('', views.answers, name='answers')
]