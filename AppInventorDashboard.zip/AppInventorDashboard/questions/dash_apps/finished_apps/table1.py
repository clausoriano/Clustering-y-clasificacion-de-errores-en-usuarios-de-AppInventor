
import pymysql as pymysql
from dash import dcc
from dash import html, Dash, dash_table
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from dash import dash_table
import dash_bootstrap_components as dbc
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

query = "SELECT link,title,owner,username,text,score,views,date,time,about,tags,site,sentiments,similars,cluster FROM questions WHERE text != ''"
cursor.execute(query)
data = cursor.fetchall()
df = pd.DataFrame(data, columns=['link','title','owner','username','text','score','views','date','time','about','tags','site','sentiments','similars','cluster'])
site_labels={0:'Stack Overflow',1:'App Inventor Community Forum'}
cat_labels = {'5':'MIT AppInventor Help','20':'Bugs and Other Issues','11':'General Discussion','17':'Extensions','10':'Open Source Development','19':'App Inventor for iOS',
          '12':'Tutorials and Guides','18':'App Showcase','14':'Data Storage','24':'Frequently Asked Questions','3':'Site Feedback','21':'Work for Hire','13':'User Interface and Graphics',
          '27':'Appathon','7':'Community','9':'News/Announcements','16':'Artificial Intelligence','29':'MIT App Inventor Alexa','28':'Translating App Inventor'}
df['site'] = df['site'].map(site_labels)
df['about'] = df['about'].map(cat_labels)
dff=df

query = "SELECT question_id,answer_id,owner,score,category,text,date,time FROM answers"
cursor.execute(query)
data = cursor.fetchall()
af = pd.DataFrame(data, columns=['question_id','answer_id','owner','score','category','text','date','time'])
aff = af

query = "SELECT * FROM ai_answers WHERE ai_answer != ''"
cursor.execute(query)
data = cursor.fetchall()
ia_answers = pd.DataFrame(data, columns=['question_id','ai_answer','ai_suggested_answer'])

query = "SELECT * FROM ai_tags"
cursor.execute(query)
data = cursor.fetchall()
ia_tags = pd.DataFrame(data, columns=['question_id','suggested_tags'])


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

from django_plotly_dash import DjangoDash
app = DjangoDash('table1', external_stylesheets=external_stylesheets)


app.layout = html.Div([
    dash_table.DataTable(
        id='datatable-interactivity',
        columns=[
            {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
            for i in df.columns
        ],
        hidden_columns=['sentiments','similars','cluster'],
        data=df.to_dict('records'),
        style_cell={    # ensure adequate header width when text is shorter than cell's text
            'overflow': 'hidden',
            'textOverflow': 'ellipsis',
            'maxWidth':50,
            'minWidth': 30,
            'width': 50
        },
        editable=False,
        filter_action="native",
        sort_action="native",
        sort_mode="single",
        column_selectable="none",
        row_selectable="single",
        row_deletable=False,
        selected_rows=[],
        page_action="native",
        page_current=0,
        page_size=10,
        tooltip_delay=0,
        tooltip_duration=None,
        tooltip_data=
        [
             {
                 column: {'value': str(value), 'type': 'markdown'}
                 for column, value in row.items()
             } for row in df.to_dict('records')
        ],
        css=[
            {
                'selector': '.dash-table-tooltip',
                'rule': 'background-color: grey; color: white;'
            }
        ],
        style_cell_conditional=[  # align text columns to left. By default they are aligned to right
            {
                'if': {'column_id': c},
                'textAlign': 'left'
            } for c in ['text', 'title']
        ],

    ),

    html.Div([
        html.Div(id='display_selected_row',style={'width': '50%','height':'20%','display': 'inline-block','float':'left'}),
        html.Div(dcc.Graph(id='fig'),style={'width': '50%','height':'100%','display': 'inline-block','float':'right'}),
        html.Div(id='accepted_answer',style={'width': '50%', 'height': '20%', 'display': 'inline-block', 'float': 'right'}),
        html.Div(id='display_suggested_tag',style={'width': '30%', 'height': '20%', 'display': 'inline-block', 'float': 'left'}),
        html.Div(id='display_similars',style={'width': '60%', 'height': '20%', 'display': 'inline-block', 'float': 'right'}),
    ]),




])

@app.callback([
    Output('display_selected_row', 'children'),
    Output('fig', 'figure'),
    Output('accepted_answer', 'children'),
    Output('display_suggested_tag', 'children'),
    Output('display_similars', 'children'),
], [Input('datatable-interactivity', 'selected_rows')])
def update_answers(selected_rows):

    if len(selected_rows) == 0:
        questions = af
    else:

        row = dff.iloc[selected_rows]['link']
        sentiment = dff.iloc[selected_rows]['sentiments']
        tags = dff.iloc[selected_rows]['tags']
        tags = tags.reset_index(drop=True)
        tags = tags.iloc[0]
        similars = dff.iloc[selected_rows]['similars']
        similars = similars.reset_index(drop=True)
        similars = similars.iloc[0]
        similar_questions_df = create_similar_questions_df(similars)

        if tags == "":
            suggested_tags = ia_tags.loc[ia_tags['question_id'] == int(row.iloc[0])]
            suggested_tags = suggested_tags.reset_index(drop=True)
            suggested_tags = suggested_tags.iloc[0]['suggested_tags']
            suggested_tags = str(suggested_tags)
            suggested_tags_df = create_suggested_tags_df(suggested_tags)

        else:
            suggested_tags_df = pd.DataFrame(columns=['tag','description'])

        sentiments = sentiment.iloc[0].split(",")
        anger = float(sentiments[0].split(":")[1])
        disgust = float(sentiments[1].split(":")[1])
        fear = float(sentiments[2].split(":")[1])
        joy = float(sentiments[3].split(":")[1])
        neutral = float(sentiments[4].split(":")[1])
        sadness = float(sentiments[5].split(":")[1])
        surprise = float(sentiments[6].split(":")[1])

        anger = round(anger * 100, 1)
        disgust = round(disgust * 100, 1)
        fear = round(fear * 100, 1)
        joy = round(joy * 100, 1)
        neutral = round(neutral * 100, 1)
        sadness = round(sadness * 100, 1)
        surprise = round(surprise * 100, 1)

        data = [['Anger',anger],['Disgust',disgust],['Fear',fear],['Joy',joy],['Neutral',neutral],['Sadness',sadness],['Surprise',surprise]]
        sentiments_df = pd.DataFrame(data,columns=['name','value'])

        questions = af.loc[af['question_id'] == int(row.iloc[0])]
        accepted_answer = questions.loc[questions['category']== 'acceptedAnswer']

        if accepted_answer.empty:
            ia_suggested_answer = ia_answers.loc[ia_answers['question_id'] == int(row.iloc[0])]
            ia_suggested_answer = ia_suggested_answer.reset_index(drop=True)
            ia_suggested_answer_id = ia_suggested_answer['ai_suggested_answer']

            if not(ia_suggested_answer_id.empty):
                ia_suggested_answer_id = ia_suggested_answer_id.iloc[0]
                ia_suggested_answer_text = aff.loc[aff['answer_id'] == int(ia_suggested_answer_id)]['text']
                ia_suggested_answer_text.reset_index(drop=True)
                ia_suggested_answer_text = ia_suggested_answer_text.iloc[0]

            else:
                ia_suggested_answer_text = "AI answer for this question has not been processed yet. Try running data analysis."
                ia_suggested_answer_id = ""

            accepted_answer = html.Div([
                html.H6("AI suggested answer: " + str(ia_suggested_answer_id)),
                html.P(ia_suggested_answer_text, style={'width': '100%','height':'200px','display': 'inline-block','float':'right','vertical-align':'bottom','overflow-y':'scroll'})
            ]),
        else:
            accepted_answer = str(accepted_answer['text'].values[0])
            accepted_answer = html.Div([
                html.H6("Accepted answer:"),
                html.P(accepted_answer, style={'width': '100%','height':'200px','display': 'inline-block','float':'right','vertical-align':'bottom','overflow-y':'scroll'})
            ])

        fig = px.bar(sentiments_df, x='name', y='value')
        title = 'Sentiment analysis of question Nº' + str(row.iloc[0])
        fig.update_layout(title_text=title)


    display_selected_rows = html.Div([
        html.Div([
            html.H6("Answers to question Nº" + str(row.iloc[0])),
            dash_table.DataTable(
                id='datatable-answers',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
                    for i in questions.columns
                ],
                data=questions.to_dict('records'),
                style_cell={  # ensure adequate header width when text is shorter than cell's text
                    'overflow': 'hidden',
                    'textOverflow': 'ellipsis',
                    'maxWidth': 50,
                    'minWidth': 30,
                    'width': 50
                },
                hidden_columns=['question_id'],
                editable=False,
                filter_action="none",
                sort_action="native",
                sort_mode="single",
                row_deletable=False,
                selected_rows=[],
                page_action="native",
                page_current=0,
                page_size=9,
                tooltip_delay=0,
                cell_selectable=False,
                tooltip_duration=None,
                tooltip_data=
                [
                    {
                        column: {'value': str(value), 'type': 'markdown'}
                        for column, value in row.items()
                    } for row in questions.to_dict('records')
                ],
                css=[
                    {
                        'selector': '.dash-table-tooltip',
                        'rule': 'background-color: grey; color: white;'
                    }
                ],
                style_cell_conditional=[  # align text columns to left. By default they are aligned to right
                    {
                        'if': {'column_id': c},
                        'textAlign': 'left'
                    } for c in ['text', 'title']
                ],

            ),
        ],style={'width': '100%','display': 'inline-block','float':'left'}),
        html.Div([
            html.H5([]),
        ],style={'width': '49%','height':'100%','display': 'inline-block','float':'right'})

    ])


    display_suggested_tags = html.Div([
        html.Div([
            html.H6("AI suggested tags for question Nº" + str(row.iloc[0])),
            dash_table.DataTable(
                id='datatable-answers',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
                    for i in suggested_tags_df.columns
                ],
                data=suggested_tags_df.to_dict('records'),
                style_cell={  # ensure adequate header width when text is shorter than cell's text
                    'overflow': 'hidden',
                    'textOverflow': 'ellipsis',
                    'maxWidth': 50,
                    'minWidth': 30,
                    'width': 50
                },
                hidden_columns=['question_id'],
                editable=False,
                filter_action="none",
                sort_action="native",
                sort_mode="single",
                row_deletable=False,
                selected_rows=[],
                page_action="native",
                page_current=0,
                page_size=9,
                tooltip_delay=0,
                cell_selectable=False,
                tooltip_duration=None,
                tooltip_data=
                [
                    {
                        column: {'value': str(value), 'type': 'markdown'}
                        for column, value in row.items()
                    } for row in suggested_tags_df.to_dict('records')
                ],
                css=[
                    {
                        'selector': '.dash-table-tooltip',
                        'rule': 'background-color: grey; color: white;'
                    }
                ],
                style_cell_conditional=[  # align text columns to left. By default they are aligned to right
                    {
                        'if': {'column_id': c},
                        'textAlign': 'left'
                    } for c in ['text', 'title']
                ],

            ),
        ], style={'width': '100%', 'display': 'inline-block', 'float': 'left'}),
        html.Div([
            html.H5([]),
        ], style={'width': '49%', 'height': '100%', 'display': 'inline-block', 'float': 'right'})

    ])

    display_similar_questions = html.Div([
        html.Div([
            html.H6("Similar questions to question Nº" + str(row.iloc[0])),
            dash_table.DataTable(
                id='datatable-answers',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
                    for i in similar_questions_df.columns
                ],
                data=similar_questions_df.to_dict('records'),
                style_cell={  # ensure adequate header width when text is shorter than cell's text
                    'overflow': 'hidden',
                    'textOverflow': 'ellipsis',
                    'maxWidth': 50,
                    'minWidth': 30,
                    'width': 50
                },
                hidden_columns=['question_id'],
                editable=False,
                filter_action="none",
                sort_action="native",
                sort_mode="single",
                row_deletable=False,
                selected_rows=[],
                page_action="native",
                page_current=0,
                page_size=9,
                tooltip_delay=0,
                cell_selectable=False,
                tooltip_duration=None,
                tooltip_data=
                [
                    {
                        column: {'value': str(value), 'type': 'markdown'}
                        for column, value in row.items()
                    } for row in similar_questions_df.to_dict('records')
                ],
                css=[
                    {
                        'selector': '.dash-table-tooltip',
                        'rule': 'background-color: grey; color: white;'
                    }
                ],
                style_cell_conditional=[  # align text columns to left. By default they are aligned to right
                    {
                        'if': {'column_id': c},
                        'textAlign': 'left'
                    } for c in ['text', 'title']
                ],

            ),
        ], style={'width': '100%', 'display': 'inline-block', 'float': 'left'}),
        html.Div([
            html.H5([]),
        ], style={'width': '49%', 'height': '100%', 'display': 'inline-block', 'float': 'right'})

    ])

    return display_selected_rows, fig, accepted_answer,display_suggested_tags,display_similar_questions


def create_suggested_tags_df(suggested_tags):
    suggested_tags = suggested_tags.replace("[","")
    suggested_tags = suggested_tags.replace("]", "")
    suggested_tags = suggested_tags.replace(" ","")
    suggested_tags = suggested_tags.replace("'", "")
    suggested_tags = suggested_tags.split(",")

    tag = []
    description = []
    for suggested_tag in suggested_tags:
        query = "SELECT name,description FROM tags WHERE name = %s"
        params = [suggested_tag]
        cursor.execute(query,params)
        data = cursor.fetchall()
        if len(data) != 0:
            tag.append(data[0][0])
            description.append(data[0][1])

    d = {'tag': tag, 'description': description}
    suggested_tags_df = pd.DataFrame(d)
    return suggested_tags_df


def create_similar_questions_df(similars):
    similars = similars.replace(',','')
    similars = similars.split(' ')

    link = []
    title = []
    text = []
    for similar in similars:
        query = "SELECT link,title,text FROM questions WHERE link = %s"
        params = [similar]
        cursor.execute(query,params)
        data = cursor.fetchall()
        if len(data) != 0:
            link.append(data[0][0])
            title.append(data[0][1])
            text.append(data[0][2])

    d = {'link': link, 'title':title, 'text':text}
    similar_questions_df = pd.DataFrame(d)
    return similar_questions_df