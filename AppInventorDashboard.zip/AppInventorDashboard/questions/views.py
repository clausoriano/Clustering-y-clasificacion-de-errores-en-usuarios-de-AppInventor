from django.shortcuts import render

# Create your views here.
def questions(requests):
    return render(requests, 'questions/questions.html')