from django.urls import path
from . import views
from questions.dash_apps.finished_apps import table1

urlpatterns = [
    path('', views.questions, name='questions')

]