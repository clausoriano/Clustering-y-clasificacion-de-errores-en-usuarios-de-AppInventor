import pymysql as pymysql
from dash import dcc
from dash import html, Dash, dash_table
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
import re
from dash import dash_table
import dash_bootstrap_components as dbc
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

# Tags dataframe
query = "SELECT name,description,anger,disgust,fear,joy,neutral,sadness,surprise FROM tags"
cursor.execute(query)
data = cursor.fetchall()
df = pd.DataFrame(data, columns=['name','description','anger','disgust','fear','joy','neutral','sadness','surprise'])
tags_df = df

# Categories query
query = "SELECT name,tags FROM categories"
cursor.execute(query)
categories = cursor.fetchall()


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

from django_plotly_dash import DjangoDash
app = DjangoDash('table_tags', external_stylesheets=external_stylesheets)

# App layout
app.layout = html.Div([
    html.Div([
        dash_table.DataTable(
            id='datatable-tags',
            columns=[
                {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
                for i in tags_df.columns
            ],
            hidden_columns=['anger','disgust','fear','joy','neutral','sadness','surprise'],
            data=tags_df.to_dict('records'),
            style_cell={  # ensure adequate header width when text is shorter than cell's text
                'overflow': 'hidden',
                'textOverflow': 'ellipsis',
                'maxWidth': 50,
                'minWidth': 30,
                'width': 50
            },
            editable=False,
            filter_action="native",
            sort_action="native",
            sort_mode="single",
            column_selectable="none",
            row_selectable="single",
            row_deletable=False,
            selected_rows=[],
            page_action="native",
            page_current=0,
            page_size=10,
            tooltip_delay=0,
            tooltip_duration=None,
            tooltip_data=
            [
                {
                    column: {'value': str(value), 'type': 'markdown'}
                    for column, value in row.items()
                } for row in tags_df.to_dict('records')
            ],
            css=[
                {
                    'selector': '.dash-table-tooltip',
                    'rule': 'background-color: grey; color: white;'
                }
            ],
            style_cell_conditional=[  # align text columns to left. By default they are aligned to right
                {
                    'textAlign': 'left'
                }
            ],

        ),
    ],style={'width': '100%','height':'50%','display': 'inline-block','float':'left'}),


    html.Div([
        html.Div([dcc.Graph(id='piechart')],style={'width': '50%','height':'50%','display': 'inline-block','float':'right'}),
        html.Div([dcc.Graph(id='barchart')],style={'width': '50%','height':'50%','display': 'inline-block','float':'left'})
    ]),

])

@app.callback(Output('piechart', 'figure'), Output('barchart', 'figure'),[Input('datatable-tags', 'selected_rows')])
def display_value(selected_rows):

    selected_tag = tags_df.iloc[selected_rows]['name']
    selected_tag = selected_tag.reset_index(drop=True)
    selected_tag = selected_tag[0]

    categories_list = []
    values_list = []
    for category in categories:
        tags = category[1]
        tags = re.findall('\(.*?\)', tags)
        for tag in tags:
            tag = tag.replace("(", "")
            tag = tag.replace(")", "")
            tag = tag.split(',')
            if tag[0] == '\''+str(selected_tag)+'\'':
                categories_list.append(category[0])
                values_list.append(int(tag[1]))



    d = {'name': categories_list, 'value': values_list}
    categories_df = pd.DataFrame(d)

    pie = px.pie(
        data_frame=categories_df,
        values='value',
        names='name',
        hole=.3,
        title='Tag #' + selected_tag + ' appearances per category'
    )

    sentiments  = tags_df.iloc[selected_rows]
    sentiments = sentiments.values.tolist()
    data = [['Anger', sentiments[0][2]], ['Disgust', sentiments[0][3]], ['Fear', sentiments[0][4]], ['Joy', sentiments[0][5]], ['Neutral', sentiments[0][6]],['Sadness', sentiments[0][7]], ['Surprise', sentiments[0][8]]]
    sentiments_df = pd.DataFrame(data, columns=['name', 'value'])

    bars = px.bar(sentiments_df, x='name', y='value')
    title = 'Sentiment analysis of tag #' + selected_tag
    bars.update_layout(title_text=title)

    return pie,bars
