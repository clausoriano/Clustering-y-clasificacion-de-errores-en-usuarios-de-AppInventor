from django.shortcuts import render

# Create your views here.
def tags(requests):
    return render(requests, 'tags/tags.html')