from django.urls import path
from . import views
from tags.dash_apps.finished_apps import table_tags

urlpatterns = [
    path('', views.tags, name='tags')

]