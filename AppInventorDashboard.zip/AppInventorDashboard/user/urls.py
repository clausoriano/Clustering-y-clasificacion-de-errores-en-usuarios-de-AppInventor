from django.urls import path
from . import views
from user.dash_apps.finished_apps import table_users

urlpatterns = [
    path('', views.user, name='user')

]