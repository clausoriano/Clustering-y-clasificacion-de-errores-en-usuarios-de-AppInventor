from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.views.decorators.clickjacking import xframe_options_exempt

# Create your views here.

def user(requests):
    return render(requests, 'user/user.html')