from collections import Counter

import pymysql as pymysql
from dash import dcc
from dash import html
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from dash import dash_table
from django.conf import settings

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']


conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

from django_plotly_dash import DjangoDash
app = DjangoDash('table_users', external_stylesheets=external_stylesheets)

# Users dataframe
query = "SELECT owner,username,location FROM users"
cursor.execute(query)
users = cursor.fetchall()
df_users = pd.DataFrame(users,columns=['ID','Username','Location'])
dff_users = df_users

# Questions dataframe
query = "SELECT link,title,owner,username,text,score,views,date,time,about,tags,sentiments FROM questions"
cursor.execute(query)
questions = cursor.fetchall()
df_questions = pd.DataFrame(questions,columns=['link','title','owner','username','text','score','views','date','time','about','tags','sentiments'])
dff_questions = df_questions
cat_labels = {'5':'MIT App Inventor Help','20':'Bugs and Other Issues','11':'General Discussion','17':'Extensions','10':'Open Source Development','19':'App Inventor for iOS',
          '12':'Tutorials and Guides','18':'App Showcase','14':'Data Storage','24':'Frequently Asked Questions','3':'Site Feedback','21':'Work for Hire','13':'User Interface and Graphics',
          '27':'Appathon','7':'Community','9':'News/Announcements','16':'Artificial Intelligence','29':'MIT App Inventor Alexa','28':'Translating App Inventor'}
dff_questions['about'] = dff_questions['about'].map(cat_labels)

# Answers dataframe
query = "SELECT question_id,answer_id,owner,score,category,text,date,time,sentiments FROM answers"
cursor.execute(query)
answers = cursor.fetchall()
df_answers = pd.DataFrame(answers,columns=['question_id','answer_id','owner','score','category','text','date','time','sentiments'])
dff_answers = df_answers

# Locations dataframe
query = "SELECT name,latitude,longitude FROM locations"
cursor.execute(query)
locations = cursor.fetchall()
df_loc = pd.DataFrame(locations,columns=['name','latitude','longitude'])


table4 = px.scatter_mapbox(df_loc,lat='latitude', lon='longitude', hover_name="name",center=dict(lat=0, lon=180), zoom=0.5,mapbox_style="stamen-terrain")
table4.update_layout(coloraxis_showscale=False)

# App Layout
app.layout = html.Div([
    dash_table.DataTable(
        id='datatable-users',
        columns=[
            {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
            for i in dff_users.columns
        ],
        hidden_columns=['sentiments'],
        data=dff_users.to_dict('records'),
        style_cell={    # ensure adequate header width when text is shorter than cell's text
            'overflow': 'hidden',
            'textOverflow': 'ellipsis',
            'maxWidth':50,
            'minWidth': 30,
            'width': 50
        },
        editable=False,
        filter_action="native",
        sort_action="native",
        sort_mode="single",
        column_selectable="none",
        row_selectable="single",
        row_deletable=False,
        selected_rows=[],
        page_action="native",
        page_current=0,
        page_size=10,
        tooltip_delay=0,
        tooltip_duration=None,
        tooltip_data=
        [
             {
                 column: {'value': str(value), 'type': 'markdown'}
                 for column, value in row.items()
             } for row in dff_users.to_dict('records')
        ],
        css=[
            {
                'selector': '.dash-table-tooltip',
                'rule': 'background-color: grey; color: white;'
            }
        ],
        style_cell_conditional=[  # align text columns to left. By default they are aligned to right
            {
                'if': {'column_id': c},
                'textAlign': 'left'
            } for c in ['text', 'title']
        ],

    ),

    html.Div([
        html.Div(dcc.Graph(id='fig'),style={'width': '50%', 'height': '100%', 'display': 'inline-block', 'float': 'right'}),
        html.Div([dcc.Graph(id='pie')],style={'width': '45%','height':'20%','display': 'inline-block','float':'left'}),
        html.Div(id='question_table',style={'width': '45%','height':'20%','display': 'inline-block','float':'left'}),
        html.Div(id='answer_table',style={'width': '45%', 'height': '20%', 'display': 'inline-block', 'float': 'right'}),
        html.Div([dcc.Graph(figure=table4)],style={'width': '100%', 'height': '20%', 'display': 'inline-block', 'float': 'left'}),
    ]),
])

# App Callback
@app.callback([Output('fig', 'figure'),Output('pie', 'figure'),Output('question_table','children'),Output('answer_table','children')],[Input('datatable-users', 'selected_rows')])
def update_figures(selected_rows):
    if len(selected_rows) == 0:
        sentiments_dataframe = pd.DataFrame()
    else:
        user_id = dff_users.iloc[selected_rows]['ID']
        user_id = user_id.iloc[0]

        username = dff_users.iloc[selected_rows]['Username']
        username = username.iloc[0]

        user_questions = dff_questions.loc[dff_questions['owner'] == user_id]

        user_answers = dff_answers.loc[dff_answers['owner'] == user_id]
        user_questions_sentiments = user_questions['sentiments']
        user_answers_sentiments = user_answers['sentiments']

        user_questions_sentiments = user_questions_sentiments.values.tolist()
        user_answers_sentiments = user_answers_sentiments.values.tolist()

        sentiments_dataframe = get_sentiments(user_questions_sentiments,user_answers_sentiments)

        sentiments = ['anger', 'disgust', 'fear', 'joy', 'neutral', 'sadness', 'surprise']

        fig = go.Figure(data=[
            go.Bar(name='Questions', x=sentiments,
                   y=[float(sentiments_dataframe.iloc[0]['anger']), float(sentiments_dataframe.iloc[0]['disgust']), float(sentiments_dataframe.iloc[0]['fear']),
                      float(sentiments_dataframe.iloc[0]['joy']), float(sentiments_dataframe.iloc[0]['neutral']), float(sentiments_dataframe.iloc[0]['sadness']),
                      float(sentiments_dataframe.iloc[0]['surprise'])]),
            go.Bar(name='Answers', x=sentiments,
                   y=[float(sentiments_dataframe.iloc[1]['anger']), float(sentiments_dataframe.iloc[1]['disgust']), float(sentiments_dataframe.iloc[1]['fear']),
                      float(sentiments_dataframe.iloc[1]['joy']), float(sentiments_dataframe.iloc[1]['neutral']), float(sentiments_dataframe.iloc[1]['sadness']),
                      float(sentiments_dataframe.iloc[1]['surprise'])]),

        ])

        user_questions_categories = user_questions['about']
        user_questions_categories = user_questions_categories.values.tolist()
        counter = Counter(user_questions_categories)
        user_questions_categories_list = [list(i) for i in counter.items()]

        about_list = []
        value_list = []
        for elem in user_questions_categories_list:
            about_list.append(elem[0])
            value_list.append(elem[1])

        d = {'name': about_list, 'value': value_list}
        about_df = pd.DataFrame(d)

        pie = px.pie(
            data_frame=about_df,
            values='value',
            names='name',
            hole=.3,
            title='Categories asked by ' + username
        )

        questions_table = html.Div([
            html.H6("Questions made by " + username),
            html.Div([
                dash_table.DataTable(
                    id='datatable-questions',
                    columns=[
                        {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
                        for i in user_questions.columns
                    ],
                    data=user_questions.to_dict('records'),
                    style_cell={  # ensure adequate header width when text is shorter than cell's text
                        'overflow': 'hidden',
                        'textOverflow': 'ellipsis',
                        'maxWidth': 50,
                        'minWidth': 30,
                        'width': 50
                    },
                    hidden_columns=['question_id','owner','sentiments','username','time'],
                    editable=False,
                    filter_action="none",
                    sort_action="native",
                    sort_mode="single",
                    row_deletable=False,
                    selected_rows=[],
                    page_action="native",
                    page_current=0,
                    page_size=10,
                    tooltip_delay=0,
                    cell_selectable=False,
                    tooltip_duration=None,
                    tooltip_data=
                    [
                        {
                            column: {'value': str(value), 'type': 'markdown'}
                            for column, value in row.items()
                        } for row in user_questions.to_dict('records')
                    ],
                    css=[
                        {
                            'selector': '.dash-table-tooltip',
                            'rule': 'background-color: grey; color: white;'
                        }
                    ],
                    style_cell_conditional=[  # align text columns to left. By default they are aligned to right
                        {
                            'if': {'column_id': c},
                            'textAlign': 'left'
                        } for c in ['text', 'title']
                    ],

                ),
            ], style={'width': '100%', 'display': 'inline-block', 'float': 'left'}),
            html.Div([
                html.H5([]),
            ], style={'width': '49%', 'height': '100%', 'display': 'inline-block', 'float': 'right'})

        ])

        answers_table = html.Div([
            html.H6("Answers made by " + username),
            html.Div([
                dash_table.DataTable(
                    id='datatable-answers',
                    columns=[
                        {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
                        for i in user_answers.columns
                    ],
                    data=user_answers.to_dict('records'),
                    style_cell={  # ensure adequate header width when text is shorter than cell's text
                        'overflow': 'hidden',
                        'textOverflow': 'ellipsis',
                        'maxWidth': 50,
                        'minWidth': 30,
                        'width': 50
                    },
                    hidden_columns=['question_id','owner','sentiments','username','time'],
                    editable=False,
                    filter_action="none",
                    sort_action="native",
                    sort_mode="single",
                    row_deletable=False,
                    selected_rows=[],
                    page_action="native",
                    page_current=0,
                    page_size=10,
                    tooltip_delay=0,
                    cell_selectable=False,
                    tooltip_duration=None,
                    tooltip_data=
                    [
                        {
                            column: {'value': str(value), 'type': 'markdown'}
                            for column, value in row.items()
                        } for row in user_answers.to_dict('records')
                    ],
                    css=[
                        {
                            'selector': '.dash-table-tooltip',
                            'rule': 'background-color: grey; color: white;'
                        }
                    ],
                    style_cell_conditional=[  # align text columns to left. By default they are aligned to right
                        {
                            'if': {'column_id': c},
                            'textAlign': 'left'
                        } for c in ['text', 'title']
                    ],

                ),
            ], style={'width': '100%', 'display': 'inline-block', 'float': 'left'}),
            html.Div([
                html.H5([]),
            ], style={'width': '49%', 'height': '100%', 'display': 'inline-block', 'float': 'right'})

        ])



    return fig,pie,questions_table,answers_table

def get_sentiments(questions_list,answers_list):
    anger = 0
    disgust = 0
    fear = 0
    joy = 0
    neutral = 0
    sadness = 0
    surprise = 0
    cont = 0

    for sentiment in questions_list:
        if sentiment != '':
            sentiments = sentiment.split(",")
            anger = anger + float(sentiments[0].split(":")[1])
            disgust = disgust + float(sentiments[1].split(":")[1])
            fear = fear + float(sentiments[2].split(":")[1])
            joy = joy + float(sentiments[3].split(":")[1])
            neutral = neutral + float(sentiments[4].split(":")[1])
            sadness = sadness + float(sentiments[5].split(":")[1])
            surprise = surprise + float(sentiments[6].split(":")[1])
            cont = cont + 1

    if cont == 0:
        cont = 1

    anger = round(anger / cont * 100, 1)
    disgust = round(disgust / cont * 100, 1)
    fear = round(fear / cont * 100, 1)
    joy = round(joy / cont * 100, 1)
    neutral = round(neutral / cont * 100, 1)
    sadness = round(sadness / cont * 100, 1)
    surprise = round(surprise / cont * 100, 1)

    d1 = ['Questions',anger,disgust,fear,joy,neutral,sadness,surprise]

    anger = 0
    disgust = 0
    fear = 0
    joy = 0
    neutral = 0
    sadness = 0
    surprise = 0
    cont = 0

    for sentiment in answers_list:
        if sentiment != '':
            sentiments = sentiment.split(",")
            anger = anger + float(sentiments[0].split(":")[1])
            disgust = disgust + float(sentiments[1].split(":")[1])
            fear = fear + float(sentiments[2].split(":")[1])
            joy = joy + float(sentiments[3].split(":")[1])
            neutral = neutral + float(sentiments[4].split(":")[1])
            sadness = sadness + float(sentiments[5].split(":")[1])
            surprise = surprise + float(sentiments[6].split(":")[1])
            cont = cont + 1

    if cont == 0:
        cont = 1

    anger = round(anger / cont * 100, 1)
    disgust = round(disgust / cont * 100, 1)
    fear = round(fear / cont * 100, 1)
    joy = round(joy / cont * 100, 1)
    neutral = round(neutral / cont * 100, 1)
    sadness = round(sadness / cont * 100, 1)
    surprise = round(surprise / cont * 100, 1)

    d2 = ['Answers',anger,disgust,fear,joy,neutral,sadness,surprise]

    d = [d1, d2]
    dataframe = pd.DataFrame(d, columns=['name', 'anger', 'disgust', 'fear', 'joy', 'neutral', 'sadness', 'surprise'])
    return dataframe