from django.shortcuts import render

# Create your views here.
def categories(requests):
    return render(requests, 'categories/categories.html')