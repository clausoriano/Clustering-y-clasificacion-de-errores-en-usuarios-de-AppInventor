import pymysql as pymysql
from dash import dcc
from dash import html
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from dash import dash_table
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

query = "SELECT name,anger,disgust,fear,joy,neutral,sadness,surprise FROM categories"
cursor.execute(query)
data = cursor.fetchall()
df = pd.DataFrame(data, columns=['name','anger','disgust','fear','joy','neutral','sadness','surprise'])
dff = df

query = "SELECT name, description, ans_mean_time, questions,answers,likes,views FROM categories"
cursor.execute(query)
data = cursor.fetchall()
cat_df = pd.DataFrame(data, columns=['category','description','answer mean time (days)','nº of questions','nº of answers', 'likes','views'])

query = "SELECT date,about FROM questions"
cursor.execute(query)
data = cursor.fetchall()
timeline_df = pd.DataFrame(data, columns=['date','about'])
timeline_dff = timeline_df
test = timeline_dff.groupby(['date','about'],as_index=False).size()
test.info()
column_headers = list(test.columns.values)
print (column_headers)

cat_labels = {'5':'MIT AppInventor Help','20':'Bugs and Other Issues','11':'General Discussion','17':'Extensions','10':'Open Source Development','19':'App Inventor for iOS',
          '12':'Tutorials and Guides','18':'App Showcase','14':'Data Storage','24':'Frequently Asked Questions','3':'Site Feedback','21':'Work for Hire','13':'User Interface and Graphics',
          '27':'Appathon','7':'Community','9':'News/Announcements','16':'Artificial Intelligence','29':'MIT App Inventor Alexa','28':'Translating App Inventor'}
test['about'] = test['about'].map(cat_labels)

query = "SELECT latitude,longitude,count FROM locations"
cursor.execute(query)
data = cursor.fetchall()
df_locations = pd.DataFrame(data,columns=['latitude','longitude','count'])
dff_locations = df_locations


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

from django_plotly_dash import DjangoDash
app = DjangoDash('table_categories', external_stylesheets=external_stylesheets)

sentiments=['anger', 'disgust', 'fear', 'joy', 'neutral', 'sadness', 'surprise']

fig = go.Figure(data=[
    go.Bar(name= dff.iloc[0]['name'], x=sentiments, y=[float(dff.iloc[0]['anger']), float(dff.iloc[0]['disgust']), float(dff.iloc[0]['fear']), float(dff.iloc[0]['joy']), float(dff.iloc[0]['neutral']), float(dff.iloc[0]['sadness']), float(dff.iloc[0]['surprise'])]),
    go.Bar(name='Bugs and Other Issues', x=sentiments, y=[float(dff.iloc[1]['anger']), float(dff.iloc[1]['disgust']), float(dff.iloc[1]['fear']), float(dff.iloc[1]['joy']), float(dff.iloc[1]['neutral']), float(dff.iloc[1]['sadness']), float(dff.iloc[1]['surprise'])]),
    go.Bar(name='General Discussion', x=sentiments, y=[float(dff.iloc[2]['anger']), float(dff.iloc[2]['disgust']), float(dff.iloc[2]['fear']), float(dff.iloc[2]['joy']), float(dff.iloc[2]['neutral']), float(dff.iloc[2]['sadness']), float(dff.iloc[2]['surprise'])]),
    go.Bar(name='Extensions', x=sentiments, y=[float(dff.iloc[3]['anger']), float(dff.iloc[3]['disgust']), float(dff.iloc[3]['fear']), float(dff.iloc[3]['joy']), float(dff.iloc[3]['neutral']), float(dff.iloc[3]['sadness']), float(dff.iloc[3]['surprise'])]),
    go.Bar(name='Open Source Development', x=sentiments, y=[float(dff.iloc[4]['anger']), float(dff.iloc[4]['disgust']), float(dff.iloc[4]['fear']), float(dff.iloc[4]['joy']), float(dff.iloc[4]['neutral']), float(dff.iloc[4]['sadness']), float(dff.iloc[4]['surprise'])]),
    go.Bar(name='App Inventor for iOS', x=sentiments, y=[float(dff.iloc[5]['anger']), float(dff.iloc[5]['disgust']), float(dff.iloc[5]['fear']), float(dff.iloc[5]['joy']), float(dff.iloc[5]['neutral']), float(dff.iloc[5]['sadness']), float(dff.iloc[5]['surprise'])]),
    go.Bar(name='Tutorials and Guides', x=sentiments, y=[float(dff.iloc[6]['anger']), float(dff.iloc[6]['disgust']), float(dff.iloc[6]['fear']), float(dff.iloc[6]['joy']), float(dff.iloc[6]['neutral']), float(dff.iloc[6]['sadness']), float(dff.iloc[6]['surprise'])]),
    go.Bar(name='App Showcase', x=sentiments, y=[float(dff.iloc[7]['anger']), float(dff.iloc[7]['disgust']), float(dff.iloc[7]['fear']), float(dff.iloc[7]['joy']), float(dff.iloc[7]['neutral']), float(dff.iloc[7]['sadness']), float(dff.iloc[7]['surprise'])]),
    go.Bar(name='Data Storage', x=sentiments, y=[float(dff.iloc[8]['anger']), float(dff.iloc[8]['disgust']), float(dff.iloc[8]['fear']), float(dff.iloc[8]['joy']), float(dff.iloc[8]['neutral']), float(dff.iloc[8]['sadness']), float(dff.iloc[8]['surprise'])]),
    go.Bar(name=' Frequently Asked Questions', x=sentiments, y=[float(dff.iloc[9]['anger']), float(dff.iloc[9]['disgust']), float(dff.iloc[9]['fear']), float(dff.iloc[9]['joy']), float(dff.iloc[9]['neutral']), float(dff.iloc[9]['sadness']), float(dff.iloc[9]['surprise'])]),
    go.Bar(name='Site Feedback', x=sentiments, y=[float(dff.iloc[10]['anger']), float(dff.iloc[10]['disgust']), float(dff.iloc[10]['fear']), float(dff.iloc[10]['joy']), float(dff.iloc[10]['neutral']), float(dff.iloc[10]['sadness']), float(dff.iloc[10]['surprise'])]),
    go.Bar(name='Work for Hire', x=sentiments, y=[float(dff.iloc[11]['anger']), float(dff.iloc[11]['disgust']), float(dff.iloc[11]['fear']), float(dff.iloc[11]['joy']), float(dff.iloc[11]['neutral']), float(dff.iloc[11]['sadness']), float(dff.iloc[11]['surprise'])]),
    go.Bar(name='User Interface and Graphics', x=sentiments, y=[float(dff.iloc[12]['anger']), float(dff.iloc[12]['disgust']), float(dff.iloc[12]['fear']), float(dff.iloc[12]['joy']), float(dff.iloc[12]['neutral']), float(dff.iloc[12]['sadness']), float(dff.iloc[12]['surprise'])]),
    go.Bar(name='Appathon', x=sentiments, y=[float(dff.iloc[13]['anger']), float(dff.iloc[13]['disgust']), float(dff.iloc[13]['fear']), float(dff.iloc[13]['joy']), float(dff.iloc[13]['neutral']), float(dff.iloc[13]['sadness']), float(dff.iloc[13]['surprise'])]),
    go.Bar(name='Community', x=sentiments, y=[float(dff.iloc[14]['anger']), float(dff.iloc[14]['disgust']), float(dff.iloc[14]['fear']), float(dff.iloc[14]['joy']), float(dff.iloc[14]['neutral']), float(dff.iloc[14]['sadness']), float(dff.iloc[14]['surprise'])]),
    go.Bar(name='News/Announcements', x=sentiments, y=[float(dff.iloc[15]['anger']), float(dff.iloc[15]['disgust']), float(dff.iloc[15]['fear']), float(dff.iloc[15]['joy']), float(dff.iloc[15]['neutral']), float(dff.iloc[15]['sadness']), float(dff.iloc[15]['surprise'])]),
    go.Bar(name='Artificial Intelligence', x=sentiments, y=[float(dff.iloc[16]['anger']), float(dff.iloc[16]['disgust']), float(dff.iloc[16]['fear']), float(dff.iloc[16]['joy']), float(dff.iloc[16]['neutral']), float(dff.iloc[16]['sadness']), float(dff.iloc[16]['surprise'])]),
    go.Bar(name='MIT App Inventor Alexa', x=sentiments, y=[float(dff.iloc[17]['anger']), float(dff.iloc[17]['disgust']), float(dff.iloc[17]['fear']), float(dff.iloc[17]['joy']), float(dff.iloc[17]['neutral']), float(dff.iloc[17]['sadness']), float(dff.iloc[17]['surprise'])]),
    go.Bar(name='Translating App Inventor', x=sentiments, y=[float(dff.iloc[18]['anger']), float(dff.iloc[18]['disgust']), float(dff.iloc[18]['fear']), float(dff.iloc[18]['joy']), float(dff.iloc[18]['neutral']), float(dff.iloc[18]['sadness']), float(dff.iloc[18]['surprise'])]),
])
# Change the bar mode
fig.update_layout(barmode='group',yaxis={"categoryorder":"total descending"},title='Sentiment Analysis')

fig2 = px.line(test, x="date", y="size", color='about',symbol='about',title='Categories timeline')
fig3 = px.scatter(test, x="date", y="size", color='about',title='Categories timeline')


app.layout = html.Div([
dash_table.DataTable(
        id='datatable-answers',
        columns=[
            {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
            for i in cat_df.columns
        ],
        hidden_columns=['sentiments'],
        data=cat_df.to_dict('records'),
        style_cell={    # ensure adequate header width when text is shorter than cell's text
            'overflow': 'hidden',
            'textOverflow': 'ellipsis',
            'maxWidth':50,
            'minWidth': 30,
            'width': 50,
        },
        editable=False,
        filter_action="native",
        sort_action="native",
        sort_mode="single",
        row_deletable=False,
        selected_rows=[],
        page_action="native",
        page_current=0,
        page_size=10,
        tooltip_delay=0,
        tooltip_duration=None,
        tooltip_data=
        [
             {
                 column: {'value': str(value), 'type': 'markdown'}
                 for column, value in row.items()
             } for row in cat_df.to_dict('records')
        ],
        css=[
            {
                'selector': '.dash-table-tooltip',
                'rule': 'background-color: grey; color: white;'
            }
        ],
        style_cell_conditional=[  # align text columns to left. By default they are aligned to right
            {
                'textAlign': 'left'
            }
        ],

    ),
    dcc.Graph(figure=fig),
    #dcc.Graph(figure=fig2),
    dcc.Graph(figure=fig3),
])