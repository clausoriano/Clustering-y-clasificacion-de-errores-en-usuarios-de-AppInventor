
import re
import pymysql as pymysql
from dash import dcc, dash_table
from dash import html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from django.conf import settings

conn = pymysql.connect(user=settings.DBUSER, password=settings.DBPASS, host=settings.DBHOST, database=settings.DBNAME)
cursor = conn.cursor()

query = "SELECT ID,link,title,owner,username,text,score,views,date,time,about,tags,sentiments,site FROM questions"
cursor.execute(query)
data = cursor.fetchall()
df = pd.DataFrame(data, columns=['ID','link','title','owner','username','text','score','views','date','time','about','tags','sentiments','site'])
cat_labels = {'5':'MIT App Inventor Help','20':'Bugs and Other Issues','11':'General Discussion','17':'Extensions','10':'Open Source Development','19':'App Inventor for iOS',
          '12':'Tutorials and Guides','18':'App Showcase','14':'Data Storage','24':'Frequently Asked Questions','3':'Site Feedback','21':'Work for Hire','13':'User Interface and Graphics',
          '27':'Appathon','7':'Community','9':'News/Announcements','16':'Artificial Intelligence','29':'MIT App Inventor Alexa','28':'Translating App Inventor'}
site_labels={0:'Stack Overflow',1:'App Inventor Community Forum'}
df['about'] = df['about'].map(cat_labels)
df['site'] = df['site'].map(site_labels)

query = "SELECT ID,name,tags FROM categories"
cursor.execute(query)
data = cursor.fetchall()
df_cats = pd.DataFrame(data,columns=['ID','name','tags'])
dff_cats = df_cats

query = "SELECT ID,name,top_users FROM categories"
cursor.execute(query)
data = cursor.fetchall()
df_top_users = pd.DataFrame(data,columns=['ID','name','top_users'])
dff_top_users = df_top_users

query = "SELECT latitude,longitude,name FROM locations"
cursor.execute(query)
data = cursor.fetchall()
df_locations = pd.DataFrame(data,columns=['latitude','longitude','name'])
dff_locations = df_locations

query = "SELECT * FROM users"
cursor.execute(query)
data = cursor.fetchall()
users = pd.DataFrame(data,columns=['ID','owner','username','location','latitude','longitude'])

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

from django_plotly_dash import DjangoDash
app = DjangoDash('table_categories2', external_stylesheets=external_stylesheets)


app.layout = html.Div([
    html.Div([
    html.H6(['Most relevant questions in:']),
        dcc.Dropdown(
            id='my_dropdown',
            options=[
                {'label': 'MIT App Inventor Help', 'value': 'MIT App Inventor Help'},
                {'label': 'Bugs and Other Issues', 'value': 'Bugs and Other Issues'},
                {'label': 'General Discussion', 'value': 'General Discussion'},
                {'label': 'Extensions', 'value': 'Extensions'},
                {'label': 'Open Source Development', 'value': 'Open Source Development'},
                {'label': 'App Inventor for iOS', 'value': 'App Inventor for iOS'},
                {'label': 'Tutorials and Guides', 'value': 'Tutorials and Guides'},
                {'label': 'App Showcase', 'value': 'App Showcase'},
                {'label': 'Data Storage', 'value': 'Data Storage'},
                {'label': 'Site Feedback', 'value': 'Site Feedback'},
                {'label': 'Work for Hire', 'value': 'Work for Hire'},
                {'label': 'User Interface and Graphics', 'value': 'User Interface and Graphics'},
                {'label': 'Appathon', 'value': 'Appathon'},
                {'label': 'Community', 'value': 'Community'},
                {'label': 'News/Announcements', 'value': 'News/Announcements'},
                {'label': 'Artificial Intelligence', 'value': 'Artificial Intelligence'},
                {'label': 'MIT App Inventor Alexa', 'value': 'MIT App Inventor Alexa'},
                {'label': 'Translating App Inventor', 'value': 'Translating App Inventor'},
                {'label': 'Frequently Asked Questions', 'value': 'Frequently Asked Questions'},
            ],
            value='MIT App Inventor Help',
            multi=False,
            clearable=False,
            style={"width":"50%"}
        ),
    ]),

    html.Div([
        html.Div(id='table1',style={'width': '45%','height':'20%','display': 'inline-block','float':'left'}),
        html.Div([dcc.Graph(id='table2')],style={'width': '45%','height':'20%','display': 'inline-block','float':'right'}),
        html.Div(id='table3',style={'width': '30%','height':'20%','display': 'inline-block','float':'left'}),
        html.Div([dcc.Graph(id='table4')],style={'width': '70%', 'height': '20%', 'float': 'right'}),

    ]),
])

@app.callback(Output('table1', 'children'), Output('table2', 'figure'),Output('table3', 'children'),Output('table4', 'figure'),[Input('my_dropdown', 'value')])
def display_value(value):
    questions = df
    questions = questions.sort_values('views',ascending=False)
    questions = questions.loc[questions['about'] == value]
    users_cat = questions[['owner']]
    users_cat = users_cat.values.tolist()
    questions = questions.head(10)

    pd.set_option('display.max_colwidth', None)
    cat_tags = dff_cats
    cat_tags = cat_tags.loc[cat_tags['name'] == value]
    tags = str(cat_tags['tags'])
    list = re.findall('\(([^)]+)', tags)

    tag_list = []
    value_list = []
    for elem in list:
        elem = elem.split(",")
        tag_list.append(elem[0])
        value_list.append(elem[1])

    d = {'name': tag_list, 'value': value_list}
    tags_df = pd.DataFrame(d)
    tags_df = tags_df.head()

    dff_top_users = df_top_users.loc[df_top_users['name'] == value]
    top_users = dff_top_users['top_users']
    list = re.findall('\(([^)]+)', str(top_users))

    top_users_list = []
    value_list = []
    for elem in list:
        elem = elem.split(",")
        top_users_list.append(elem[0])
        value_list.append(elem[1])

    username_list = []
    for user in top_users_list:
        query = "SELECT username FROM users where owner = %s"
        params = [user]
        cursor.execute(query, params)
        data = cursor.fetchall()
        username_list.append(data[0][0])

    d = {'ID': top_users_list, 'username': username_list, 'participations': value_list}
    top_users_df = pd.DataFrame(d)

    latitude = []
    longitude = []
    count = []
    for user in users_cat:
        u = users.loc[users['owner'] == user[0]]
        if not u.empty:
            lat = u.iloc[0]['latitude']
            lon = u.iloc[0]['longitude']
            loc = u.iloc[0]['location']
            if (lat != 0 and lon != 0):
                latitude.append(lat)
                longitude.append(lon)
                count.append(loc)

    d = {'latitude': latitude, 'longitude': longitude, 'location': count}
    dataframe = pd.DataFrame(d)

    table2 = px.pie(
        data_frame=tags_df,
        values='value',
        names='name',
        hole=.3,
        title='Top tags used in: ' + value
    )

    table4 = px.density_mapbox(dataframe, lat='latitude', lon='longitude', radius=10,
                        center=dict(lat=0, lon=180), zoom=0.5,
                        mapbox_style="stamen-terrain"
    )
    table4.update_layout(coloraxis_showscale=False)

    table1 = html.Div([
        html.Div([
            dash_table.DataTable(
                id='datatable-answers',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
                    for i in questions.columns
                ],
                data=questions.to_dict('records'),
                style_cell={  # ensure adequate header width when text is shorter than cell's text
                    'overflow': 'hidden',
                    'textOverflow': 'ellipsis',
                    'maxWidth': 50,
                    'minWidth': 30,
                    'width': 50
                },
                hidden_columns=['about','ID','username','sentiments'],
                editable=False,
                filter_action="none",
                sort_action="native",
                sort_mode="single",
                row_deletable=False,
                selected_rows=[],
                page_action="native",
                page_current=0,
                page_size=10,
                tooltip_delay=0,
                cell_selectable=False,
                tooltip_duration=None,
                tooltip_data=
                [
                    {
                        column: {'value': str(value), 'type': 'markdown'}
                        for column, value in row.items()
                    } for row in questions.to_dict('records')
                ],
                css=[
                    {
                        'selector': '.dash-table-tooltip',
                        'rule': 'background-color: grey; color: white;'
                    }
                ],
                style_cell_conditional=[  # align text columns to left. By default they are aligned to right
                    {
                        'if': {'column_id': c},
                        'textAlign': 'left'
                    } for c in ['text', 'title']
                ],

            ),
        ], style={'width': '100%', 'display': 'inline-block', 'float': 'left'}),
        html.Div([
            html.H5([]),
        ], style={'width': '49%', 'height': '100%', 'display': 'inline-block', 'float': 'right'})

    ])

    table3 = html.Div([
        html.Div([
            html.H6(['Most active users in: ' + value]),
            dash_table.DataTable(
                id='datatable-tags',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": False, "hideable": True}
                    for i in top_users_df.columns
                ],
                data=top_users_df.to_dict('records'),
                style_cell={  # ensure adequate header width when text is shorter than cell's text
                    'overflow': 'hidden',
                    'textOverflow': 'ellipsis',
                    'maxWidth': 50,
                    'minWidth': 30,
                    'width': 50
                },
                editable=False,
                filter_action="none",
                sort_action="native",
                sort_mode="single",
                row_deletable=False,
                selected_rows=[],
                page_action="native",
                page_current=0,
                page_size=10,
                tooltip_delay=0,
                cell_selectable=False,
                tooltip_duration=None,
                tooltip_data=
                [
                    {
                        column: {'value': str(value), 'type': 'markdown'}
                        for column, value in row.items()
                    } for row in top_users_df.to_dict('records')
                ],
                css=[
                    {
                        'selector': '.dash-table-tooltip',
                        'rule': 'background-color: grey; color: white;'
                    }
                ],
                style_cell_conditional=[  # align text columns to left. By default they are aligned to right
                    {
                        'if': {'column_id': c},
                        'textAlign': 'left'
                    } for c in ['text', 'title']
                ],

            ),
        ], style={'width': '100%', 'display': 'inline-block', 'float': 'left'}),
        html.Div([
            html.H5([]),
        ], style={'width': '49%', 'height': '100%', 'display': 'inline-block', 'float': 'right'})

    ])



    return table1,table2,table3,table4

