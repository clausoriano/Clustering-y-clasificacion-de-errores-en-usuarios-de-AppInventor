from django.urls import path
from . import views
from categories.dash_apps.finished_apps import table_categories,table_categories2

urlpatterns = [
    path('', views.categories, name='categories')

]